// Created by Majdi M. S. Awad
let currentVelocity = 50;
let currentAngle = 45;
let currentTime = 5;

document.getElementById('velocity').addEventListener('input', function() {
    currentVelocity = parseInt(this.value);
    document.getElementById('velocityValue').textContent = currentVelocity;
});

document.getElementById('angle').addEventListener('input', function() {
    currentAngle = parseInt(this.value);
    document.getElementById('angleValue').textContent = currentAngle;
});

document.getElementById('time').addEventListener('input', function() {
    currentTime = parseInt(this.value);
    document.getElementById('timeValue').textContent = currentTime;
});

document.getElementById('simulationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    let velocity = currentVelocity;
    let angle = currentAngle;
    let time = currentTime;

    let distance = calculateDistance(velocity, angle, time); 

    let resultElement = document.getElementById('simulationResult');
    resultElement.innerHTML = `
        <h3>Simulation Results</h3>
        <p>Initial Velocity: ${velocity} m/s</p>
        <p>Launch Angle: ${angle} degrees</p>
        <p>Time Interval: ${time} seconds</p>
        <p>Estimated Distance: ${distance.toFixed(2)} meters</p>
    `;

    displayTrajectory(velocity, angle);
});

function calculateDistance(velocity, angle, time) {
    let radians = angle * (Math.PI / 180); 
    let g = 9.81; 
    let distance = velocity * Math.cos(radians) * time; 
    return distance;
}


function displayTrajectory(velocity, angle) {
    let radians = angle * (Math.PI / 180); 
    let g = 9.81; 
    let maxTime = 2 * velocity * Math.sin(radians) / g; 
    let timeStep = maxTime / 50;

    let dataPoints = [];
    let predictions = [];

   
    for (let offset = -5; offset <= 5; offset += 2) {
        let predictionPoints = [];
        for (let t = 0; t <= maxTime; t += timeStep) {
            let x = velocity * Math.cos(radians) * t; 
            let y = velocity * Math.sin(radians) * t - 0.5 * g * t * t + offset; 
            predictionPoints.push({ x: x, y: y });
        }
        predictions.push(predictionPoints);
    }

    for (let t = 0; t <= maxTime; t += timeStep) {
        let x = velocity * Math.cos(radians) * t; 
        let y = velocity * Math.sin(radians) * t - 0.5 * g * t * t; 
        dataPoints.push({ x: x, y: y });
    }

    let chart = new CanvasJS.Chart("trajectoryChart", {
        animationEnabled: true,
        title: {
            text: "Projectile Motion Trajectory",
            fontSize: 20,
            fontWeight: "normal",
            fontFamily: "Arial"
        },
        axisX: {
            title: "Horizontal Distance (meters)",
            titleFontSize: 14,
            labelFontSize: 12
        },
        axisY: {
            title: "Vertical Distance (meters)",
            titleFontSize: 14,
            labelFontSize: 12,
            includeZero: false
        },
        data: [{
            type: "line",
            dataPoints: dataPoints,
            markerSize: 0, 
            lineColor: "blue",
            lineThickness: 2
        }]
    });

    for (let i = 0; i < predictions.length; i++) {
        chart.options.data.push({
            type: "line",
            dataPoints: predictions[i],
            lineColor: "rgba(255, 0, 0, 0.5)",
            lineDashType: "dash",
            lineThickness: 1
        });
    }

    chart.render();
}
