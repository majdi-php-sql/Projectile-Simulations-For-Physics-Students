/* 
This code created by Majdi M. S. Awad
*/
CREATE DATABASE IF NOT EXISTS missile_simulation;
USE missile_simulation;

CREATE TABLE IF NOT EXISTS simulations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    velocity FLOAT NOT NULL,
    angle FLOAT NOT NULL,
    time FLOAT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);