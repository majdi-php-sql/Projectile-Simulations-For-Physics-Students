<?php
// Created by Majdi Awad
function sanitize($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "missile_simulation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $velocity = sanitize($_POST['velocity']);
    $angle = sanitize($_POST['angle']);
    $time = sanitize($_POST['time']);

    if (!is_numeric($velocity) || !is_numeric($angle) || !is_numeric($time)) {
        die("Error: Invalid input values. Please enter numeric values.");
    }

    $stmt = $conn->prepare("INSERT INTO simulations (velocity, angle, time) VALUES (?, ?, ?)");
    $stmt->bind_param("ddd", $velocity, $angle, $time);

    if ($stmt->execute()) {
        echo "Simulation data saved successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
